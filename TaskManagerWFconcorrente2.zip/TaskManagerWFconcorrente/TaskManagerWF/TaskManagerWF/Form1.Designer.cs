﻿namespace TaskManagerWF {
    partial class Form1 {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.description = new System.Windows.Forms.Label();
            this.Error = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.hostname = new System.Windows.Forms.Label();
            this.hostnameTB = new System.Windows.Forms.TextBox();
            this.port = new System.Windows.Forms.Label();
            this.portTB = new System.Windows.Forms.TextBox();
            this.connectButton = new System.Windows.Forms.Button();
            this.politoImg2 = new System.Windows.Forms.PictureBox();
            this.politoImg = new System.Windows.Forms.PictureBox();
            this.Title = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.politoImg2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.politoImg)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.flowLayoutPanel1, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(19, 49);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 37.36264F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 62.63736F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1131, 82);
            this.tableLayoutPanel1.TabIndex = 13;
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.flowLayoutPanel2.Controls.Add(this.description);
            this.flowLayoutPanel2.Controls.Add(this.Error);
            this.flowLayoutPanel2.Location = new System.Drawing.Point(4, 4);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(1123, 23);
            this.flowLayoutPanel2.TabIndex = 8;
            this.flowLayoutPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel2_Paint);
            // 
            // description
            // 
            this.description.AutoSize = true;
            this.description.Font = new System.Drawing.Font("Segoe UI Light", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.description.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.description.Location = new System.Drawing.Point(3, 0);
            this.description.Name = "description";
            this.description.Size = new System.Drawing.Size(533, 21);
            this.description.TabIndex = 0;
            this.description.Text = "Insert server\'s name and port , then click Connet in order to proceed";
            // 
            // Error
            // 
            this.Error.AutoSize = true;
            this.Error.Font = new System.Drawing.Font("Segoe UI Light", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Error.ForeColor = System.Drawing.Color.Red;
            this.Error.Location = new System.Drawing.Point(542, 0);
            this.Error.Name = "Error";
            this.Error.Size = new System.Drawing.Size(0, 21);
            this.Error.TabIndex = 17;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.flowLayoutPanel1.Controls.Add(this.hostname);
            this.flowLayoutPanel1.Controls.Add(this.hostnameTB);
            this.flowLayoutPanel1.Controls.Add(this.port);
            this.flowLayoutPanel1.Controls.Add(this.portTB);
            this.flowLayoutPanel1.Controls.Add(this.connectButton);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(4, 34);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(909, 41);
            this.flowLayoutPanel1.TabIndex = 5;
            // 
            // hostname
            // 
            this.hostname.AutoSize = true;
            this.hostname.Font = new System.Drawing.Font("Segoe UI Light", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hostname.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.hostname.Location = new System.Drawing.Point(3, 0);
            this.hostname.Name = "hostname";
            this.hostname.Size = new System.Drawing.Size(87, 21);
            this.hostname.TabIndex = 3;
            this.hostname.Text = "Hostname";
            // 
            // hostnameTB
            // 
            this.hostnameTB.BackColor = System.Drawing.SystemColors.Window;
            this.hostnameTB.Font = new System.Drawing.Font("Segoe UI Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hostnameTB.Location = new System.Drawing.Point(96, 3);
            this.hostnameTB.Name = "hostnameTB";
            this.hostnameTB.Size = new System.Drawing.Size(345, 29);
            this.hostnameTB.TabIndex = 1;
            this.hostnameTB.Enter += new System.EventHandler(this.disableKeyPreview);
            this.hostnameTB.Leave += new System.EventHandler(this.enableKeyPreview);
            // 
            // port
            // 
            this.port.AutoSize = true;
            this.port.Font = new System.Drawing.Font("Segoe UI Light", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.port.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.port.Location = new System.Drawing.Point(447, 0);
            this.port.Name = "port";
            this.port.Size = new System.Drawing.Size(42, 21);
            this.port.TabIndex = 4;
            this.port.Text = "Port";
            // 
            // portTB
            // 
            this.portTB.BackColor = System.Drawing.SystemColors.Window;
            this.portTB.Font = new System.Drawing.Font("Segoe UI Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.portTB.Location = new System.Drawing.Point(495, 3);
            this.portTB.Name = "portTB";
            this.portTB.Size = new System.Drawing.Size(128, 29);
            this.portTB.TabIndex = 2;
            this.portTB.Enter += new System.EventHandler(this.disableKeyPreview);
            this.portTB.Leave += new System.EventHandler(this.enableKeyPreview);
            // 
            // connectButton
            // 
            this.connectButton.Font = new System.Drawing.Font("Segoe UI Light", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.connectButton.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.connectButton.Location = new System.Drawing.Point(629, 3);
            this.connectButton.Name = "connectButton";
            this.connectButton.Size = new System.Drawing.Size(140, 29);
            this.connectButton.TabIndex = 0;
            this.connectButton.Text = "Connect";
            this.connectButton.UseVisualStyleBackColor = true;
            this.connectButton.Click += new System.EventHandler(this.connectToServer);
            // 
            // politoImg2
            // 
            this.politoImg2.BackColor = System.Drawing.Color.Transparent;
            this.politoImg2.Image = ((System.Drawing.Image)(resources.GetObject("politoImg2.Image")));
            this.politoImg2.InitialImage = ((System.Drawing.Image)(resources.GetObject("politoImg2.InitialImage")));
            this.politoImg2.Location = new System.Drawing.Point(1218, 39);
            this.politoImg2.Name = "politoImg2";
            this.politoImg2.Size = new System.Drawing.Size(114, 120);
            this.politoImg2.TabIndex = 12;
            this.politoImg2.TabStop = false;
            this.politoImg2.Visible = false;
            // 
            // politoImg
            // 
            this.politoImg.Image = global::TaskManagerWF.Properties.Resources.polito_torino;
            this.politoImg.Location = new System.Drawing.Point(670, 207);
            this.politoImg.Name = "politoImg";
            this.politoImg.Size = new System.Drawing.Size(476, 439);
            this.politoImg.TabIndex = 11;
            this.politoImg.TabStop = false;
            this.politoImg.Click += new System.EventHandler(this.politoImg_Click);
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Segoe UI Light", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Title.Location = new System.Drawing.Point(16, 5);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(271, 41);
            this.Title.TabIndex = 14;
            this.Title.Text = "Task Manager App";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button1.Font = new System.Drawing.Font("Segoe UI Light", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.button1.Location = new System.Drawing.Point(1010, 137);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 22);
            this.button1.TabIndex = 5;
            this.button1.Text = "Close Server";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 246);
            this.label1.MaximumSize = new System.Drawing.Size(600, 0);
            this.label1.MinimumSize = new System.Drawing.Size(600, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(600, 340);
            this.label1.TabIndex = 15;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 380);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.politoImg2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.politoImg);
            this.Controls.Add(this.button1);
            this.DoubleBuffered = true;
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Task Manager App";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Form1_KeyPressed);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel2.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.politoImg2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.politoImg)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox politoImg;
        private System.Windows.Forms.PictureBox politoImg2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Label description;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label hostname;
        private System.Windows.Forms.TextBox hostnameTB;
        private System.Windows.Forms.Label port;
        private System.Windows.Forms.TextBox portTB;
        private System.Windows.Forms.Button connectButton;
        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Label Error;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
    }
}

