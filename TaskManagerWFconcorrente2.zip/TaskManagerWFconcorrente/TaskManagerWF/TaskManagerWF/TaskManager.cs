﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;
using System.Diagnostics;
using System.Drawing;


namespace TaskManagerWF {
    class TaskManager {

        //Reference to the server manager to which the task manager belongs to 
        ServerManager sm = null;
        internal Object thislock = new Object();
        //Dictionary with AppName as key and Application as value, it contains all the application open on the server 
        Dictionary<string, Appl> applicationList = new Dictionary<string, Appl>();
        UInt32 appListLen = 0;
        Dictionary<string, Appl> applicationAdded = new Dictionary<string, Appl>();
        Dictionary<string, Appl> applicationRemoved = new Dictionary<string, Appl>();

        //It represents the app with the focus at the moment
        Appl focus = null;
        //Used by form1 render function 
        string _oldFocus;
        
        //All socket variables 
        IPHostEntry ipHostInfo = null;
        IPAddress ipAddress = null;
        IPEndPoint remoteEP = null;
        SocketType sockType = SocketType.Stream;
        ProtocolType sockProtocol = ProtocolType.Tcp;
        Socket clientSocket = null;

        //Number of background workers that manages this task manager
        private int _ticket;
        internal Stopwatch totalTime;
        private bool _firstRender = true;
        bool processData = true;
        bool firstCom = true;
        string cmd = null;
        string hostname;
        int portNum;

        //Class constructor 
        public TaskManager(ServerManager servM) {
            //Set the handle to the server manager
            sm = servM;
        }

        public string getName() {
            return hostname;
        }

        public string OldFocus {
            get {
                return _oldFocus;
            }
        }

        public List<Appl> getApplicationAdded() {
            return applicationAdded.Values.ToList();
        }

        public List<Appl> getApplicationRemoved() {
            return applicationRemoved.Values.ToList();
        }

        public int Ticket{
            get {
                return _ticket;
            }
            set {
                _ticket = value;
            }
        }

        public Appl getFocus() {
            return focus;
        }

        public List<Appl> getAppList() {
            return applicationList.Values.ToList();
        }

        public bool FirstRender {
            get {
                return _firstRender;
            }
        }

        public void setHost(String str) {
            hostname = str;
        }

        public void setPort(int port) {
            portNum = port;
        }

        //Read a number on 4 bytes from the socket
        public UInt32 readNum() {
            UInt32 num = 0;
            byte[] array = new byte[4];
            int bytesRec = clientSocket.Receive(array);
            if (bytesRec == 4) {
                if (BitConverter.IsLittleEndian)
                    Array.Reverse(array);
                num = BitConverter.ToUInt32(array, 0);
            }
            return num;
        }

        //Read a number on 8 bytes from the socket
        public UInt64 readNum64() {
            UInt64 num = 0;
            byte[] array = new byte[8];
            int bytesRec = clientSocket.Receive(array);
            if (bytesRec == 8) {
                if (BitConverter.IsLittleEndian)
                    Array.Reverse(array);
                num = BitConverter.ToUInt64(array, 0);
            }
            return num;
        }

        public string readName() {
            //Read Appl name lenght 
            UInt32 nameLen = readNum();
            using(StreamWriter outFile = new StreamWriter("output.txt", true)) {
                outFile.WriteLine("Namelen: " + nameLen);
            }
 
            //Read Appl name
            byte[] array = new byte[nameLen];
            int bytesRec = clientSocket.Receive(array);
            string name = System.Text.Encoding.ASCII.GetString(array, 0, array.Length);
            return name;
        }

        public Appl readApp() {

            //Read the Appl id and create the Appl instance
            UInt64 id = readNum64();
            string name = readName();
            Appl a;

            if (applicationList.ContainsKey(name)) {
                //Aggiungo una handle 
                a = applicationList[name];
                if (id != 0) {
                    a.addHandle(id);
                }

            } else {
                a = new Appl();
                a.AppName = name;
                a.addHandle(id);
            }

            try {
                //Read icon size
                UInt32 icoSize = readNum();
                using (StreamWriter s = new StreamWriter("output.txt", true)) {
                    s.WriteLine("Nome: " + name);
                    s.WriteLine("IconSize: " + icoSize);
                }
                a.IconSize = icoSize;

                //Read icon data
                //byte [] read = new byte[1]; 
                byte[] array = new byte[icoSize];
                for (Int32 j = 0; j < icoSize;) {
                    //int bytesRec = clientSocket.Receive(read);
                    //Array.Copy(read, 0, array, j, bytesRec);
                    int bytesRec = clientSocket.Receive(array, j, (int)Math.Min(1024, icoSize - j), SocketFlags.None);
                    j += bytesRec;
                }
                MemoryStream ms = new MemoryStream(array);
                Icon i = new Icon(ms);
                a.Icon = i;
                return a;
            } catch (Exception e) {
                Console.WriteLine("Something wrong with icon");
                a.Icon = new Icon(SystemIcons.Exclamation, 40, 40);
                return a;
            }

        }

        public void receiveAppList() {

            appListLen = readNum();
            
            //Adding Appl to the list 
            for (int i = 0; i < appListLen; i++) {
                Appl a = readApp();
                if (applicationList.ContainsKey(a.AppName)) {
                    Console.WriteLine("Handle added to corresponding App");
                } else {
                    applicationList.Add(a.AppName, a);
                    Console.WriteLine("App " + a.ToString() + " added");
                }
            }
        }

        public void addApp() {

            //Clear the dictionary of added apps in order to fill it with the new ones
            applicationAdded.Clear();
            //Read num of app to add
            UInt32 numb = readNum();
            //Adding Appl to the list 
            for (int i = 0; i < numb; i++) {
                Appl a = readApp();
                if (applicationList.ContainsKey(a.AppName)) {
                    //If app already exsists, set her active flat to true
                    a.Active = true;
                } else {
                    applicationList.Add(a.AppName, a);
                    Console.WriteLine("App " + a.ToString() + " added");
                }
                applicationAdded.Add(a.AppName, a);
            }
        }

        public void removeApp() {

            //Clear the dictionary of added apps in order to fill it with the new ones
            applicationRemoved.Clear();
            //Read number of app to delete
            UInt32 numb = readNum();
            //Delete the app with corresponding AppID
            for (int i = 0; i < numb; i++) {
                UInt64 id = readNum64();
                string name = readName();

                if (applicationList.ContainsKey(name)) {
                    Appl a = applicationList[name];
                    if (a.removeHandle(id) == 0) {
                        //Disable entire app only if no others handles are present
                        a.Active = false;
                    }
                    applicationRemoved.Add(name, a);
                } else {
                    Console.WriteLine("This Appl does not exsist! Nothing to remove");
                }
            }
        }

        public void changeFocus() {

            UInt64 id = readNum64();
            string appName;
            if (id != 0) {
                appName = readName();
            }
            else {
                appName = "Desktop";
            }

            //Check if focus object is already created, if not send err message
            if (applicationList.ContainsKey(appName)) {
                //Remove old information from the sm 
                if (focus != null) {
                    _oldFocus = focus.AppName;
                    //App is no more on focus on this server
                    sm.removeServerFromAppList(focus, hostname);
                    //Stop the stopwatch with focus time related to the previous app
                    focus.FocusTime.Stop();
                }
                focus = applicationList[appName];
                focus.Handle = id;
                //Start the focus timer for the new app with the focus 
                focus.FocusTime.Start();
                //Update information in the server manager 
                sm.addAppToList(focus);
                sm.addServerToAppList(focus, hostname);
            } else {
                //Err message to the server! Focus is not valid
                sendErr();
            }
        }

        public void sendErr() {
            //Send the command err
            byte[] sendBuffer = new byte[3];
            sendBuffer = System.Text.Encoding.ASCII.GetBytes("err");
            int rc = clientSocket.Send(sendBuffer);
            Console.WriteLine("Client: Sent command err over {0} bytes", rc);
        }

        public void sendSockCommand(char [] usCmd, uint nMod) {
            try {
                using (StreamWriter s = new StreamWriter("comando.txt", true)) {
                    s.WriteLine("TaskM: ");
                }

                //Send the command com
                byte[] sendBuffer = new byte[3];
                sendBuffer = System.Text.Encoding.ASCII.GetBytes("com");
                int rc = clientSocket.Send(sendBuffer);
                Console.WriteLine("Client: Sent command err over {0} bytes", rc);

                //Send handle of app with focus 
                sendBuffer = new byte[8];
                UInt64 n64 = focus.Handle;
                sendBuffer = BitConverter.GetBytes(n64);
                if (BitConverter.IsLittleEndian)
                    Array.Reverse(sendBuffer);
                rc = clientSocket.Send(sendBuffer);
                Console.WriteLine("Server: Sent pid of app over {0} bytes", rc);

                //Send number of modificators
                sendBuffer = new byte[4];
                sendBuffer = BitConverter.GetBytes(nMod);
                if (BitConverter.IsLittleEndian)
                    Array.Reverse(sendBuffer);
                rc = clientSocket.Send(sendBuffer);
                Console.WriteLine("Server: Sent name size of app over {0} bytes", rc);

                //Send keyboard combination 
                StringBuilder str = new StringBuilder();
                if (usCmd[0] == 'C')
                    str.Append("CTR");
                if (usCmd[1] == 'A')
                    str.Append("ALT");
                if (usCmd[2] == 'S')
                    str.Append("SHI");
                if (usCmd[3] != '\0')
                    str.Append(usCmd[3]);
                Console.WriteLine("Combinazione: " + str);
                int len = str.Length;
                sendBuffer = new byte[len];
                sendBuffer = System.Text.Encoding.ASCII.GetBytes(str.ToString());
                rc = clientSocket.Send(sendBuffer);
                Console.WriteLine("Client: Sent command com over {0} bytes", rc);
            }catch(Exception e) {
                Console.WriteLine("Socket error while sending or reading answare from socket");
                this.close();
            }
        }

        public void readSockCommand() {
            byte[] command = new byte[3];
            int bytesRec = clientSocket.Receive(command);
            cmd = System.Text.Encoding.ASCII.GetString(command, 0, command.Length);
            Console.WriteLine("Comando: " + cmd + " Originale: " + command);
        }
        
        //Establish the connection with the server: create the socket
        public bool sockConnect() {
            try {
                // Establish the remote endpoint for the socket.
                ipHostInfo = Dns.GetHostEntry(hostname);
                if (ipHostInfo.AddressList.Length > 1) {
                    ipAddress = ipHostInfo.AddressList[1];
                } 
                else if (ipHostInfo.AddressList.Length == 0) {
                    ipAddress = IPAddress.Parse(hostname);
                }
                else {
                    ipAddress = ipHostInfo.AddressList[0];
                }
                remoteEP = new IPEndPoint(ipAddress, portNum);

                // Create a TCP/IP  client socket
                clientSocket = new Socket(AddressFamily.InterNetwork, sockType, sockProtocol);
                Console.WriteLine("Socket created");

                // Connect the socket to the remote endpoint (server). Catch any errors.
                try {
                    clientSocket.Connect(remoteEP);
                    Console.WriteLine("Socket connected to {0}", clientSocket.RemoteEndPoint.ToString());
                    //Update info related to the server in ServerManager class
                    sm.addServer(hostname);
                    
                } catch (ArgumentNullException ane) {
                    Console.WriteLine("ArgumentNullException : {0}", ane.ToString());
                    return false;
                } catch (SocketException se) {
                    Console.WriteLine("SocketException : {0}", se.ToString());
                    return false;
                } catch (Exception e) {
                    Console.WriteLine("Unexpected exception : {0}", e.ToString());
                    return false;
                }
            } catch (Exception e) {
                //Temporary!!! In the GUI there will be a connection failed message
                Console.WriteLine("Client: Socket error occurred: {0}", e.ToString());
                return false;
            }
            return true;
        }

        //Exchange data with the server through the socket
        public void sockExecute(Form1 form1) {

            try {
                //Create the app representing the desktop
                Appl a = new Appl();
                a.AppName = "Desktop";
                a.addHandle(0);
                a.Active = false;
                a.Icon = new Icon(SystemIcons.WinLogo, 40, 40);
                applicationList.Add(a.AppName, a);

                totalTime = new Stopwatch();

                while (processData) {
               
                    if(clientSocket.Poll(3000000, SelectMode.SelectRead)) { 
                        readSockCommand();

                        
                        switch (cmd) {
                            case "lis":
                                Console.WriteLine("Command lis ");
                                lock (thislock) {
                                    receiveAppList();
                                    //First time we want to be sure that the second command received is foc
                                    //If not send err to server

                                    if (firstCom == true) {
                                        firstCom = false;
                                        Console.WriteLine("Command foc1");
                                        readSockCommand();
                                        if (String.Compare(cmd, 0, "foc", 0, 3) == 0) {
                                            totalTime.Start();
                                            changeFocus();
                                        } else
                                            sendErr();
                                    }
                                }
                                form1.Invoke(form1.triggerUpdate, this, "lis");
                                _firstRender = false;
                                break;
                            case "com":
                                break;
                            case "add":
                                lock (thislock) {
                                    Console.WriteLine("Command add");
                                    addApp();
                                }
                                form1.Invoke(form1.triggerUpdate, this, "add");
                                break;
                            case "rem":
                                lock (thislock) {
                                    Console.WriteLine("Command rem");
                                    removeApp();
                                }
                                form1.Invoke(form1.triggerUpdate, this, "rem");
                                break;
                            case "foc":
                                lock (thislock) {
                                    Console.WriteLine("Command foc");
                                    changeFocus();
                                }
                                form1.Invoke(form1.triggerUpdate, this, "foc");
                                form1.Invoke(form1.triggerUpdate, this, "ren");
                                break;
                            case "+ok":
                                lock (thislock) {
                                    Console.WriteLine("OK sending command");
                                    form1.Invoke(form1.report, "+ok");
                                    Thread.Sleep(1000);
                                }
                                form1.Invoke(form1.triggerUpdate, this, "foc");
                                break;
                            case "err":
                                lock (thislock) {
                                    Console.WriteLine("Error sending command");
                                    form1.Invoke(form1.report, "err");
                                    Thread.Sleep(1000);
                                }
                                form1.Invoke(form1.triggerUpdate, this, "foc");
                                break;
                            case "clo":
                                processData = false;
                                break;
                            default:
                                Console.WriteLine("Unknown command");
                                using (StreamWriter outFile = new StreamWriter("output.txt", true)) {
                                    outFile.WriteLine("Unknown Command: ");
                                }
                                processData = false;
                                form1.CloseTm(this);
                                break;
                        }
                    }else {
                        Console.WriteLine("Timeout expired");
                        if (!firstCom) {
                            Console.WriteLine("Timeout expired2");
                            form1.Invoke(form1.triggerUpdate, this, "per");
                        }
                    }

                }

                // Release the socket.
                totalTime.Stop();
                clientSocket.Shutdown(SocketShutdown.Both);
                clientSocket.Close();

            } catch (Exception e) {
                //Temporary!!! In the GUI there will be a connection failed message
                form1.CloseTm(this);
                Console.WriteLine("Client: Socket error occurred: {0}", e.ToString());
            } finally {
                // Close the socket if necessary
                if (clientSocket != null) {
                    clientSocket.Close();
                }
            }
            return;
        }

        //Close connection with server 
        public void close() {
            if (clientSocket != null) {
                clientSocket.Close();
            }
        }
    }
}
