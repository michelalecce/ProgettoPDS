﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TaskManagerWF {
    class ServerManager {

        //For each app with focus it contains the list of servers 
        Dictionary<Appl, List<string>> applicationList;
        //General list of servers with which client is connected
        List<string> serverList;

        //Class constructor
        public ServerManager() {
            applicationList = new Dictionary<Appl, List<string>>();
            serverList = new List<string>();

        }

        //Tell how many applications are in focus globally (two servers can have the same app on focus, so this value is not
        //equal to the value of open task managers
        public int getNumApp() {
            return applicationList.Count;
        }

        //Given a certain app, this function returns the list of the name of the servers on which that app has focus
        public List<string> getServersOfApp(string name) {
            foreach (KeyValuePair<Appl, List<string>> kvp in applicationList) {
                string str = kvp.Key.AppName;
                if (name.CompareTo(str) == 0) {
                    return kvp.Value;
                }
            }
            return null;
        }

        //Returns the name of all servers (task managers) opened
        public List<String> serversList() {
            return serverList;
        }

        public Dictionary<Appl, List<string>> getAppList() {
            return applicationList;
        }
        
        public void addServer(string server) {
            serverList.Add(server);
        }

        public bool removeServer(string server) {
            if (serverList.Remove(server)) {
                return true;
            } else {
                return false;
            }
        }

        //When an app is in focus on a certain server this function add that server to the list of servers belonging to that app
        public void addServerToAppList(Appl app, string server) {
            bool added = false;
            List<string> l;
            foreach (KeyValuePair<Appl, List<string>> kvp in applicationList) {
                //If applicationList already contains an app with the same name add the server to that app
                if (kvp.Key.AppName.CompareTo(app.AppName)==0) {
                    //Add server to that list
                    kvp.Value.Add(server);
                    added = true;
                }
            }
            if (!added) {
                try {
                    applicationList.TryGetValue(app, out l);
                    l.Add(server);
                }catch(Exception ex) { }
            }
        }

        //Add an application to the list of app with focus
        public void addAppToList(Appl app) {
            List<string> l = new List<string>();
            foreach (KeyValuePair<Appl, List<string>> kvp in applicationList)
            {
                //If applicationList already contains an app with the same name add the server to that app
                if (kvp.Key.AppName.CompareTo(app.AppName) == 0)
                {
                    //Add already present
                    return;
                }
            }
            applicationList.Add(app, l);
        }

        //When a certain app is no more in focus on a certain server, remove the server from its list and if the list of servers
        //is empty remove the app itself (it is no more on focus on any server)
        public void removeServerFromAppList(Appl app, string server) {
            
            foreach (KeyValuePair<Appl, List<string>> kvp in applicationList)
            {
                //If applicationList already contains an app with the same name add the server to that app
                if (kvp.Key.AppName.CompareTo(app.AppName) == 0)
                {
                    //Add server to that list
                    kvp.Value.Remove(server);
                    if (kvp.Value.Count == 0)
                    {
                        //If there are no server in which it is active, remove the app
                        applicationList.Remove(app);
                    }
                    return;
                }
            }
        }

        //Delete a certain server from list of app in which it appears
        public void closeServer(string server) {
            List<string> l;
            try {
                foreach (KeyValuePair<Appl, List<string>> kvp in applicationList) {
                    l = kvp.Value;
                    if (l.Contains(server)) {
                        l.Remove(server);
                    }
                }
                for (int i = 0; i<applicationList.Count; i++) {
                    //If there are no server in which it is active, remove the app
                    Appl a = applicationList.ElementAt(i).Key;
                    if(applicationList[a].Count == 0) {
                        applicationList.Remove(a);
                    }
                }
            } catch (ArgumentNullException) {
            Console.WriteLine("This application has no focus");
            }
        }
        
    }
}
