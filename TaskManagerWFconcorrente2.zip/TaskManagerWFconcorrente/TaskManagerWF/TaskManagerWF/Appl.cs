﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Drawing;
using System.ComponentModel;
using System.Data;
using System.IO;


namespace TaskManagerWF {
    class Appl {

        //properties with relative public fields getter and setter
        private Stopwatch _focusTime;
        //The handle with the focus
        private UInt64 _handle;
        //All the instances of this app
        private List<UInt64> _handleIDList = null;
        //private UInt32 _nameSize = 0;
        private UInt32 _iconSize = 0;
        private string _appName = null;
        private Icon _icon = null;
        private bool _active = true;


        //constructor
        public Appl() {
            _focusTime = new Stopwatch();
            _handleIDList = new List<UInt64>();
        }

        public bool Active {
            get {
                return _active;
            }
            set {
                _active = value;
            }
        }

        public int removeHandle(UInt64 h) {
            this._handleIDList.Remove(h);
            return _handleIDList.Count;
        }

        public Stopwatch FocusTime {
            get {
                return _focusTime;
            }
            set {
                _focusTime = value;
            }
        }

        public UInt64 Handle {
            get {
                return _handle;
            }

            set {
                _handle = value;
            }
        }

        public List<UInt64> getList() {
            return _handleIDList;
        }

        public void addHandle(UInt64 h) {
            _handleIDList.Add(h);
        }

        public UInt32 IconSize {
            get {
                return _iconSize;
            }
            set {
                _iconSize = value;
            }
        }

        public string AppName {
            get {
                return _appName;
            }
            set {
                _appName = value;
            }
        }

        public Icon Icon {
            get {
                return _icon;
            }
            set {
                if (_icon == null && _iconSize != 0) {
                    //icon is empty and it has been received something from the socket
                    _icon = new Icon(SystemIcons.Exclamation, 40, 40);
                    _icon = value;
                } else if (_iconSize == 0) {
                    //default icon, no data from socket
                    _icon = new Icon(SystemIcons.Exclamation, 40, 40);
                } else {
                    _icon = value;
                }
            }
        }
        
        public string toString() {
            return "App name: " + _appName + " App icon " + _icon;
        }

        public void printApp() {
            for (int i = 0; i < _handleIDList.Count; i++) {
                Console.WriteLine("Handle " + i + ": " + _handleIDList[i]);
            }
        }
    }
}
