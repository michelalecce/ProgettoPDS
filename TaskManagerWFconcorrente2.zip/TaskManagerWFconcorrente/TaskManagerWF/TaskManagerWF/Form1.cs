﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaskManagerWF {
    
    internal delegate void updateForm(TaskManager tm, string com);
    internal delegate void clearTab();
    internal delegate void notify(string report);

    public partial class Form1 : Form {

        //This is the delegate that trigger the form's graphic update
        internal updateForm triggerUpdate;
        internal clearTab clearTabDel;
        internal notify report;

        //Resources:
        ServerManager sm;
        //Contains the reference to all the tm belonging to the serverManager
        Dictionary<string, TaskManager> serversDict;
        //The tm which is currently on rendering
        TaskManager currTM;
        bool firstConn = true, working = false;
        //Max number of connections to servers
        private const int maxWorkers = 5; 
        private System.ComponentModel.BackgroundWorker[] bW = new BackgroundWorker[maxWorkers];
        private System.Windows.Forms.TabPage servers;
        private System.Windows.Forms.TabPage [] page;
        private System.Windows.Forms.TabControl tabControl1;
        private ListView [] listViewVector = new ListView[maxWorkers+1];
        private ImageList [] imageListSmallVector = new ImageList[maxWorkers+1];
        private string oldFocus;
        //This vector represents command that user can send to the app with focus
        //usCmd[0] = 'C' ---> CTR
        //usCmd[1] = 'C' ---> ALT
        //usCmd[2] = 'C' ---> SHI
        //usCmd[3] can contain any letter, number or keycode
        char[] usCmd = { '\0', '\0', '\0', '\0' };
        //nMod indicates the number of modificators of usCmd
        UInt32 nMod = 0;
        private bool handled = false;
        private bool firstRender = true;
        private bool control = false;
        private bool shift = false;
        private bool alt = false;

        public Form1() {
            InitializeComponent();
            this.page = new System.Windows.Forms.TabPage[maxWorkers];
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.servers = new System.Windows.Forms.TabPage();
            this.initializeBackgroundWorker();

            sm = new ServerManager();
            serversDict = new Dictionary<string, TaskManager>();
            triggerUpdate += this.render; //register the form to the delegate that updates with callback to render function
            clearTabDel += this.clearServerTab;
            report += this.notifyResult;
            this.tabControl1.Selected += this.TabControl1_Selected;
        }
     
        private void sendCommand() {
            string name = tabControl1.SelectedTab.Text;
            
            if (name.CompareTo("Applications") == 0) {
                //Send command over all sockets
                string app = null;
                for (int i=0; i<listViewVector[0].Items.Count; i++) {
                    if (listViewVector[0].Items[i].Focused) {
                        app = listViewVector[i].Items[i].SubItems[0].Text;
                    }
                }
                if (app != null) {
                    List<string> list = sm.getServersOfApp(app);

                    for (int i = 0; i < list.Count; i++) {
                        TaskManager t = serversDict[list[i]];
                        if (t != null) {
                            t.sendSockCommand(usCmd, nMod);
                        }
                    }
                }
            } else {
                currTM = serversDict[name];
                currTM.sendSockCommand(usCmd, nMod);
            }
            
        }
        
        //This function associated with notify delegate is triggered by the task manager when it receives the 
        //response from the server after has sending a key comnbination
        internal void notifyResult(string res) {
            if (res.CompareTo("+ok") == 0) {
                Error.Text = "Combination sent";
            } else {
                Error.Text = "Error: wrong focused application";
            }
        }

        private void listView1_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e) {
            if (e.IsSelected)
                e.Item.Selected = false;
        }

        private void TabControl1_Selected(Object sender, TabControlEventArgs e) {

            if(tabControl1.SelectedTab == null) {
                return;
            }
            string name = tabControl1.SelectedTab.Text;
            if (name.CompareTo("Applications") == 0) {
                button1.Visible = false;
                this.render(null, "ren");
                tabControl1.SelectedIndex = 0;
            } else {
                button1.Visible = true;
                currTM = serversDict[name];
            }
        }

        internal void clearServerTab() {
            
            tabControl1.SelectedTab.Dispose();
            serversDict.Remove(currTM.getName());
            sm.closeServer(currTM.getName());
            currTM.close();
            currTM = null;
            tabControl1.SelectedIndex = 0;
            this.render(null, "ren");
            if (tabControl1.TabCount == 1) {
                tabControl1.Visible = false;
                label1.Visible = true;
                politoImg.Visible = true;
                politoImg2.Visible = false;
                button1.Visible = false;
            }
        }

        private void initializeBackgroundWorker() {
            for (int i = 0; i < maxWorkers; i++) {
                bW[i] = new BackgroundWorker();
                bW[i].WorkerReportsProgress = true;
                bW[i].DoWork += new DoWorkEventHandler(bW_DoWork);
                bW[i].ProgressChanged += new ProgressChangedEventHandler(bW_ProgressChanged);
            }
        }

        private void changeFocus() {
            Error.Text = "";
            //With a call of this function no app can be not active so omit this control
            int ticket = currTM.Ticket;
            string currentFocusName = currTM.getFocus().AppName;
            string oldFocusName = currTM.OldFocus;
            if (currentFocusName.CompareTo("Desktop") == 0) {
                Error.Text = "Desktop has focus";
            }
            if(oldFocusName == null || oldFocusName.CompareTo("Desktop") == 0) {
                //No focus before this one so simply highlight the new focused app
                ListViewItem newFoc = listViewVector[ticket].FindItemWithText(currentFocusName);
                if (newFoc != null) {
                    newFoc.BackColor = SystemColors.GradientActiveCaption;
                }
                listViewVector[ticket].Update();
                return;
            }
            ListViewItem oldF = listViewVector[ticket].FindItemWithText(oldFocusName);
            if (oldF != null) {
                int index = oldF.Index;
                if ((index % 2) == 0) {
                    //Riga Chiara
                    oldF.BackColor = SystemColors.ButtonFace;
                } else {
                    //Riga Scura
                    oldF.BackColor = SystemColors.ControlLight;
                }

                ListViewItem newF = listViewVector[ticket].FindItemWithText(currentFocusName);
                if (newF != null) {
                    //Not the case of the desktop
                    newF.BackColor = SystemColors.GradientActiveCaption;
                }
            }
            listViewVector[ticket].Update();
        }

        private void updatePerc() {
            List<Appl> appList = currTM.getAppList();
            int ticket = currTM.Ticket;
            string focus = currTM.getFocus().AppName;
            if(focus.CompareTo("Desktop") == 0) {
                Error.Text = "Desktop has focus";
            }
            for(int i=0; i<appList.Count; i++) {
                string name = appList[i].AppName;
                if (name.CompareTo("Desktop") == 0)
                    continue;
                ListViewItem item = listViewVector[ticket].FindItemWithText(name);
                if (item != null) {
                    float milliApp = appList[i].FocusTime.ElapsedMilliseconds;
                    float milliTot = currTM.totalTime.ElapsedMilliseconds;
                    float p = (milliApp / milliTot) * 100;
                    int intPerc = Convert.ToInt32(Math.Round(p));
                    string perc = intPerc.ToString() + "%";
                    item.SubItems[1].Text = perc;
                }
            }
            listViewVector[ticket].Update();
        }

        internal void render(TaskManager tm, string com) {
            
            int numNotActive = 0;
            Error.Text = "";
            Appl focus = null;
            UInt64 handle = 0; string focusName = null; List<Appl> appList = null;
            if (tm != null) {
                currTM = tm;
                focus = tm.getFocus();
                if (focus == null) {
                    Error.Text = "Connection lost";
                    clearServerTab();
                    return;
                }
                handle = focus.Handle;
                focusName = focus.AppName;
                appList = tm.getAppList();
            }
            Dictionary<Appl, List<string>> servDict = sm.getAppList();


            //Renderizza la pagina delle applicazioni
            //ListView for applications tab
            //Add items in the listview2
            if (com.CompareTo("ren") == 0) {

                if (!firstRender) {
                    imageListSmallVector[0].Images.Clear();
                    listViewVector[0].Items.Clear();
                    listViewVector[0].Clear();
                }
                firstRender = false;
                int k = -1;
                foreach (KeyValuePair<Appl, List<string>> kvp in servDict) {
                    k++;
                    string str = kvp.Key.AppName;
                    imageListSmallVector[0].Images.Add(kvp.Key.Icon.ToBitmap());
                    ListViewItem itm;
                    //Add first item
                    itm = new ListViewItem(str);
                    listViewVector[0].Items.Add(itm);
                    listViewVector[0].Items[k].ImageIndex = k;
                    listViewVector[0].Items[k].BackColor = SystemColors.ButtonFace;
                    foreach (string server in kvp.Value) {
                        k++;
                        ListViewItem item;
                        item = new ListViewItem("       " + server);
                        listViewVector[0].Items.Add(item);
                        imageListSmallVector[0].Images.Add(Properties.Resources.icona);
                        listViewVector[0].Items[k].ImageIndex = k;
                        listViewVector[0].Items[k].BackColor = SystemColors.ControlLight;
                    }
                }

                listViewVector[0].Columns.Add("Applications with list of servers: please select the application to send the command", -2, HorizontalAlignment.Left);
                listViewVector[0].SmallImageList = imageListSmallVector[0];
                if (this.tabControl1.TabCount != 0) {
                    //La closetm ha chiamato la dispose su quella pagina 
                    try
                    {
                        this.tabControl1.TabPages[0].Controls.Add(listViewVector[0]);
                    }catch(Exception e) { }
                }
                return;
            }
            //Render server's page
            //ListView for server's page
            //Add the items to the ListView. 
            // Create columns for the items and subitems.
            // Width of -2 indicates auto-size.
            lock (tm.thislock) {
                Int32 cont = tm.Ticket;
                if ((com.CompareTo("foc") == 0)) {
                    this.changeFocus();
                    return;
                }
                if (com.CompareTo("per") == 0) {
                    this.updatePerc();
                    return;
                }
                if (com.CompareTo("add") == 0) {
                    imageListSmallVector[cont].Images.Clear();
                    listViewVector[cont].Items.Clear();
                    listViewVector[cont].Clear();
                } else if (com.CompareTo("rem") == 0) {
                    //Forse seconda rem da problemi
                    imageListSmallVector[cont].Images.Clear();
                    listViewVector[cont].Items.Clear();
                    listViewVector[cont].Clear();
                } else if (com.CompareTo("lis") == 0) {
                    label1.Visible = false;
                    politoImg.Visible = false;
                    politoImg2.Visible = true;
                    this.tabControl1.SelectedTab = page[cont];
                }
                for (int i = 0; i < appList.Count; i++) {
                    if (focusName.CompareTo("Desktop") == 0) {
                        Error.Text = "Desktop is in focus";
                    }
                    if (appList[i].Active) {
                        float milliApp = appList[i].FocusTime.ElapsedMilliseconds;
                        float milliTot = tm.totalTime.ElapsedMilliseconds;
                        float p = (milliApp / milliTot) * 100;
                        int intPerc = Convert.ToInt32(Math.Round(p));
                        string perc = intPerc.ToString();
                        imageListSmallVector[cont].Images.Add(appList[i].Icon.ToBitmap());
                        //Add items in the listview
                        string[] arr = new string[2];
                        ListViewItem itm;
                        //Add first item
                        arr[0] = appList[i].AppName;
                        arr[1] = perc + "%";
                        itm = new ListViewItem(arr);
                        listViewVector[cont].Items.Add(itm);
                        listViewVector[cont].Items[i - numNotActive].ImageIndex = (i - numNotActive);
                        if ((i % 2) == 0) {
                            listViewVector[cont].Items[i - numNotActive].BackColor = SystemColors.ControlLight;
                        } else {
                            listViewVector[cont].Items[i - numNotActive].BackColor = SystemColors.ButtonFace;
                        }
                        if (focusName.CompareTo(appList[i].AppName) == 0) {
                            if (currTM.FirstRender) {
                                listViewVector[cont].Items[i - numNotActive].SubItems[1].Text = "100%";
                            }
                            listViewVector[cont].Items[i - numNotActive].BackColor = SystemColors.GradientActiveCaption;
                            oldFocus = appList[i].AppName;
                        }
                    } else {
                        //For each not active app i has not to be incremented  
                        numNotActive++; ;
                    }
                }
                listViewVector[cont].Columns.Add("App Name", 1100, HorizontalAlignment.Left);
                listViewVector[cont].Columns.Add("Relative Percentage of App usage", -2, HorizontalAlignment.Left);

                listViewVector[cont].SmallImageList = imageListSmallVector[cont];
                this.tabControl1.TabPages[cont].Controls.Add(listViewVector[cont]);
            }
        }

        internal void createServerTab(TaskManager tm) {
            int i = tm.Ticket;
            this.listViewVector[i] = new ListView();
            this.imageListSmallVector[i] = new ImageList();
            this.imageListSmallVector[i].ImageSize = new Size(32, 32);
            listViewVector[i].View = View.Details;
            listViewVector[i].BackColor = SystemColors.ButtonFace;
            listViewVector[i].Bounds = new Rectangle(new Point(0, 2), new Size(1323, 522));
            this.listViewVector[i].ItemSelectionChanged += this.listView1_ItemSelectionChanged;
           

            tabControl1.Visible = true;
            //Renderizza il tab del server
            int cont = tm.Ticket;
            this.page[cont] = new System.Windows.Forms.TabPage();
            string hostname = tm.getName();
            page[cont].Text = hostname;
            page[cont].Size = new System.Drawing.Size(1335, 550);
            page[cont].TabIndex = cont;
            
            page[cont].HorizontalScroll.Maximum = 0;
            page[cont].HorizontalScroll.Enabled = false;
            page[cont].HorizontalScroll.Visible = false;
            page[cont].AutoScroll = true;
            tabControl1.Controls.Add(page[cont]);
            button1.Visible = true;
        }

        internal void createAppTab() {
            this.servers = new System.Windows.Forms.TabPage();
            this.listViewVector[0] = new ListView();
            this.imageListSmallVector[0] = new ImageList();
            this.imageListSmallVector[0].ImageSize = new Size(32, 32);
            listViewVector[0].View = View.Details;
            listViewVector[0].BackColor = SystemColors.ControlLightLight;
            listViewVector[0].Bounds = new Rectangle(new Point(0, 2), new Size(1323, 522));
            listViewVector[0].FullRowSelect = true;
            
            tabControl1.Visible = true;
            servers.Text = "Applications";
            servers.Size = new System.Drawing.Size(1335, 550);
            servers.TabIndex = 0;

            tabControl1.Location = new System.Drawing.Point(16, 140);
            tabControl1.Size = new System.Drawing.Size(1335, 550);
            tabControl1.SelectedIndex = 0;
            tabControl1.TabIndex = 0;

            // Adds the TabControl to the form.
            this.Controls.Add(this.tabControl1);
            servers.HorizontalScroll.Maximum = 0;
            servers.HorizontalScroll.Enabled = false;
            servers.HorizontalScroll.Visible = false;
            servers.AutoScroll = true;
            // Adds the tab pages to the TabControl.
            tabControl1.Controls.Add(this.servers);
        }

        private void bW_DoWork(object sender, DoWorkEventArgs e) {
            //Get the backgroundWorker that raised this event
            BackgroundWorker worker = sender as BackgroundWorker;
            
            string hostname = hostnameTB.Text;
            int port = Int32.Parse(portTB.Text);
            if ((hostname == "") || (portTB.Text == ""))
            {
                return;
            }
            TaskManager tm = new TaskManager(sm);
            tm.setPort(port);
            tm.setHost(hostname);
            int ticket = (int)e.Argument;
            tm.Ticket = ticket;

            worker.ReportProgress(1);
            if (tm.sockConnect()) {
                currTM = tm;
                serversDict.Add(hostname, tm);

                if (firstConn) {
                    worker.ReportProgress(2);
                    firstConn = false;
                }
                worker.ReportProgress(3);
                tm.sockExecute(this);
            } else {
                worker.ReportProgress(4);
            }

        }

        private void bW_ProgressChanged(object sender, ProgressChangedEventArgs e) {
            if (e.ProgressPercentage.ToString().CompareTo("1") == 0) {
                Error.Text = "";
            }
            if (e.ProgressPercentage.ToString().CompareTo("2") == 0) {
                createAppTab();
            }
            if (e.ProgressPercentage.ToString().CompareTo("3") == 0) {
                createServerTab(currTM);
                hostnameTB.Clear();
                portTB.Clear();
            }
            if (e.ProgressPercentage.ToString().CompareTo("4") == 0) {
                hostnameTB.Clear();
                portTB.Clear();

                Error.Text = "Connection failed!";
            }

        }

        private void connectToServer(object sender, EventArgs e) {
            if (!working) {
                working = true;
                Error.Text = "";
                bool found = false;
                //Find a backWork that is not busy 
                for (int i = 0; i < maxWorkers; i++) {
                    if (bW[i].IsBusy != true) {
                        found = true;
                        bW[i].RunWorkerAsync(i + 1);
                        break;
                    }
                }
                if (found != true) {
                    Error.Text = "It is not possible to establish another connection";
                }
                working = false;
            } else return;
        }

        public void flowLayoutPanel2_Paint(Object sender, PaintEventArgs p) {

        }

        private void politoImg_Click(object sender, EventArgs e) {

        }

        private void Form1_Load(object sender, EventArgs e) {
            this.WindowState = FormWindowState.Maximized;
        }

        private void enableKeyPreview(object sender, EventArgs e) {
            this.KeyPreview = true;
        }

        private void disableKeyPreview(object sender, EventArgs e) {
            this.KeyPreview = false;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e) {
            
            //Parsing KeyCode contents
            if (e.Control && (control == false)) {
                nMod++;
                usCmd[0] = 'C';
                control = true;
            }
            if (e.Shift && (shift == false)) {
                nMod++;
                usCmd[2] = 'S';
                shift = true;
            }
            if (e.Alt && (alt == false)) {
                nMod++;
                usCmd[1] = 'A';
                alt = true;
            }
            if(e.KeyCode != Keys.ControlKey && e.KeyCode != Keys.ShiftKey && e.KeyCode != Keys.Menu) {
                //Any other keyboard key, in order to send it, convert the string into the virtual-key

                //https://msdn.microsoft.com/en-us/library/system.windows.forms.keys(v=vs.110).aspx
                //Dobbiamo estrapolare la parte alta di keyValue per catturare solo il virtual-key code (see Remarks)
                /*KeysConverter kc = new KeysConverter();
                string keyChar = kc.ConvertToString(e.KeyCode);
                char mappedChar = Convert.ToChar(keyChar);*/
                usCmd[3] = (char)e.KeyCode;
                //currTM.setKey(mappedChar);
            }

            handled = false;
            e.Handled = true;
        }

        protected override bool IsInputKey(Keys keyData) {
           
            if(keyData == Keys.Left || keyData == Keys.Right || keyData == Keys.Up || keyData == Keys.Down 
                || keyData == Keys.Tab ) {
                return true;
            }else if(keyData == Keys.Alt) {
                return true;
            }else {
                return base.IsInputKey(keyData);
            }
        }

        private void Form1_KeyPressed(object sender, KeyPressEventArgs e) {
            
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e) {

            if (e.KeyData == Keys.Tab) {
                
                if (usCmd[1].CompareTo('A') == 0) {
                    handled = true;
                    return;
                }
                
                //Tab does not raise keyDown event, do it manually!
                this.Form1_KeyDown(sender, e);
            }
            if(e.KeyData == Keys.LWin) {
                return;
            }
            
            //Ignoring LWin key and Alt + Tab, too power control to the client!!
            if(e.KeyData == Keys.Apps || e.KeyData == Keys.Delete) {
                //this.Form1_KeyDown(sender, e);
                if (usCmd[0] == 'C' && usCmd[1] == 'A' && e.KeyData == Keys.Delete) {
                    //Ignoring CTRL+ALT+CANC, we don't want the client to open server's task manager
                    handled = true;
                    return;
                }
                usCmd[3] = (char)e.KeyCode;
                
                //We set manually the keycodes of special keys that do not generate KeyDown event
            }
            Error.Text = "Sending key combination...";
            if (!handled) {
                using (StreamWriter s = new StreamWriter("comando.txt", true)) {
                    s.WriteLine("Handled flag: " + handled);
                }
                handled = true;
                if (usCmd[3] == '\0') {
                    Error.Text = "No keycode, only modificators";
                } else {
                    this.sendCommand();
                }
            }
            if (!(e.Control) && (control == true)) {
                usCmd[0] = '\0';
                nMod--;
                control = false;
            }
            if (!(e.Shift) && (shift == true)) {
                nMod--;
                usCmd[2] = '\0';
                shift = false;
            }
            if (!(e.Alt) && (alt == true)) {
                nMod--;
                usCmd[1] = '\0';
                alt = false;
            }
            if (e.KeyCode != Keys.ControlKey && e.KeyCode != Keys.ShiftKey && e.KeyCode != Keys.Menu) {
                usCmd[3] = '\0';
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e) {
            try {
                List<string> list = sm.serversList();

                for (int i = 0; i < list.Count; i++) {
                    TaskManager t = serversDict[list[i]];
                    t.close();
                }
            }catch(Exception ex) {
                Console.WriteLine("Closing without no servers active");
            }
        }

        internal void CloseTm(TaskManager tm) {
            Control.CheckForIllegalCrossThreadCalls = false;
            int i = tm.Ticket;
            listViewVector[i].Dispose();
            page[i].Dispose();
            serversDict.Remove(tm.getName());
            sm.closeServer(tm.getName());
            Error.Text = "Server closed connection";
            this.render(null, "ren");
            if (tabControl1.TabCount == 1) {
                firstConn = true;
                firstRender = true;
                listViewVector[0].Dispose();
                this.servers.Dispose();
                tabControl1.Visible = false;
                label1.Visible = true;
                politoImg.Visible = true;
                politoImg2.Visible = false;
                button1.Visible = false;
            }
            Control.CheckForIllegalCrossThreadCalls = true;
        }

        private void button1_Click(object sender, EventArgs e) {
            int i = currTM.Ticket;
            listViewVector[i].Dispose();
            page[i].Dispose();
            serversDict.Remove(currTM.getName());
            sm.closeServer(currTM.getName());
            currTM.close();
            currTM = null;
            tabControl1.SelectedIndex = 0;
            this.render(null, "ren");
            if (tabControl1.TabCount == 1) {
                firstConn = true;
                firstRender = true;
                listViewVector[0].Dispose();
                this.servers.Dispose();
                tabControl1.Visible = false;
                label1.Visible = true;
                politoImg.Visible = true;
                politoImg2.Visible = false;
                button1.Visible = false;
            }
        }
    }
}
