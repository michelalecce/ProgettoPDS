﻿========================================================================
    APPLICAZIONE CONSOLE: cenni preliminari sul progetto ServerProgettoPDS
========================================================================

La creazione guidata applicazione ha creato questa applicazione ServerProgettoPDS.

Questo file contiene un riepilogo del contenuto di ciascun file che fa parte
dell'applicazione ServerProgettoPDS.


ServerProgettoPDS.vcxproj
    File di progetto principale per i progetti VC++ generati tramite una creazione guidata applicazione. Contiene informazioni sulla versione di Visual C++ che ha generato il file e informazioni sulle piattaforme, le configurazioni e le caratteristiche del progetto selezionate con la Creazione guidata applicazione.

ServerProgettoPDS.vcxproj.filters
    File dei filtri per i progetti VC++ generati tramite una Creazione guidata applicazione. Contiene informazioni sull'associazione tra i file del progetto e i filtri. Tale associazione viene utilizzata nell'IDE per la visualizzazione di raggruppamenti di file con estensioni simili in un nodo specifico, ad esempio: i file con estensione cpp sono associati al filtro "File di origine".

ServerProgettoPDS.cpp
    File di origine principale dell'applicazione.

/////////////////////////////////////////////////////////////////////////////
Altri file standard:

StdAfx.h, StdAfx.cpp
    Tali file vengono utilizzati per generare il file di intestazione precompilato ServerProgettoPDS.pch e il file dei tipi precompilato StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Altre note:

La creazione guidata applicazione utilizza i commenti "TODO:" per indicare le
parti del codice sorgente da aggiungere o personalizzare.

/////////////////////////////////////////////////////////////////////////////
